package com.example.jarvis

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var transcript: TextView
    private lateinit var input: EditText
    private var tts: TextToSpeech? = null
    private val prefs by lazy { getSharedPreferences("jarvis_data", MODE_PRIVATE) }
    private val speechRequestCode = 4102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
        addLine("جارفيس", "أهلاً! أنا النسخة الأولية من جارفيس. اكتب «مساعدة» حتى تشوف الأوامر.")
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 20)
            setBackgroundColor(0xFF101827.toInt())
        }

        val title = TextView(this).apply {
            text = "JARVIS"
            textSize = 28f
            setTextColor(0xFF75D4FF.toInt())
            gravity = Gravity.CENTER
        }
        root.addView(title, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))

        val subtitle = TextView(this).apply {
            text = "مساعدك الشخصي • نسخة 0.1"
            textSize = 14f
            setTextColor(0xFFB8C8DC.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 6, 0, 18)
        }
        root.addView(subtitle)

        val scroll = ScrollView(this)
        transcript = TextView(this).apply {
            textSize = 16f
            setTextColor(0xFFEDF4FF.toInt())
            setPadding(14, 14, 14, 14)
            setBackgroundColor(0xFF1B2739.toInt())
            textDirection = TextView.TEXT_DIRECTION_FIRST_STRONG
        }
        scroll.addView(transcript)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        input = EditText(this).apply {
            hint = "اكتب أمراً لجارفيس..."
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF9BAEC4.toInt())
            setSingleLine(false)
            setPadding(14, 10, 14, 10)
        }
        root.addView(input, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 0)
        }
        val send = Button(this).apply {
            text = "إرسال"
            setOnClickListener {
                val command = input.text.toString().trim()
                if (command.isNotEmpty()) {
                    input.setText("")
                    handleCommand(command)
                }
            }
        }
        val mic = Button(this).apply {
            text = "🎙 تحدث"
            setOnClickListener { startSpeechInput() }
        }
        row.addView(send, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(mic, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(row)
        setContentView(root)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("ar"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.language = Locale.getDefault()
            }
        }
    }

    private fun addLine(who: String, message: String) {
        runOnUiThread {
            transcript.append("\n\n$who: $message")
            val parent = transcript.parent
            if (parent is ScrollView) parent.post { parent.fullScroll(ScrollView.FOCUS_DOWN) }
        }
    }

    private fun say(message: String) {
        addLine("جارفيس", message)
        tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    private fun startSpeechInput() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-IQ")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "احچي ويا جارفيس")
        }
        try {
            startActivityForResult(intent, speechRequestCode)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "ماكو خدمة تعرّف صوت مثبتة على الجهاز.", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Using activity result API compatible with simple MVP")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == speechRequestCode && resultCode == RESULT_OK) {
            val results = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val spoken = results?.firstOrNull()?.trim().orEmpty()
            if (spoken.isNotEmpty()) {
                addLine("أنت (صوت)", spoken)
                handleCommand(spoken, alreadyDisplayed = true)
            }
        }
    }

    private fun handleCommand(raw: String, alreadyDisplayed: Boolean = false) {
        if (!alreadyDisplayed) addLine("أنت", raw)
        val c = raw.lowercase(Locale.ROOT).trim()
        val reply = when {
            c.contains("مساعدة") || c == "help" || c.contains("الأوامر") ->
                "أكدر حالياً أذكر الوقت والتاريخ، أفتح يوتيوب أو غوغل، أحفظ ملاحظة وأعرض الملاحظات."
            c.contains("الوقت") || c == "time" ->
                "الوقت الآن " + SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            c.contains("التاريخ") || c == "date" ->
                "تاريخ اليوم " + SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            c.contains("افتح يوتيوب") || c.contains("open youtube") -> {
                openUrl("https://www.youtube.com/")
                "حاولت أفتح يوتيوب."
            }
            c.contains("افتح غوغل") || c.contains("افتح جوجل") || c.contains("open google") -> {
                openUrl("https://www.google.com/")
                "حاولت أفتح غوغل."
            }
            c.startsWith("اكتب ملاحظة") || c.startsWith("سجل ملاحظة") -> {
                val note = raw.substringAfter("ملاحظة", "").trim(' ', ':', '،')
                if (note.isBlank()) "اكتب نص الملاحظة بعد عبارة «اكتب ملاحظة»."
                else {
                    val old = prefs.getString("notes", "") ?: ""
                    val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())
                    prefs.edit().putString("notes", (old + "\n[$stamp] $note").trim()).apply()
                    "حفظت الملاحظة على الموبايل."
                }
            }
            c.contains("اعرض الملاحظات") || c.contains("اقرأ الملاحظات") -> {
                val notes = prefs.getString("notes", "") ?: ""
                if (notes.isBlank()) "ما عندك ملاحظات محفوظة."
                else "هذه ملاحظاتك: $notes"
            }
            c.contains("من أنت") || c.contains("منو انت") || c.contains("who are you") ->
                "أنا جارفيس، نسخة أولية مجانية تعمل على موبايلك. حالياً أنفذ أوامر محددة."
            else ->
                "بعدني ما أتعرف على هذا الأمر. اكتب «مساعدة» حتى تشوف الأوامر المتاحة."
        }
        say(reply)
    }

    private fun openUrl(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW).apply { data = android.net.Uri.parse(url) })
        } catch (_: Exception) {
            Toast.makeText(this, "تعذر فتح الرابط.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
